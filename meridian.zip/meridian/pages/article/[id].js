import { useState } from "react";
import Head from "next/head";
import { useRouter } from "next/router";
import { Ticker, Masthead, Footer } from "../../components/Layout";

const QA_CHIPS = [
  "What are the key unknowns?",
  "Who are the main actors?",
  "What's the historical context?",
  "What happens next?",
];

export default function ArticlePage({ article }) {
  const router = useRouter();
  const [qaMessages, setQaMessages] = useState([]);
  const [qaInput, setQaInput] = useState("");
  const [qaLoading, setQaLoading] = useState(false);

  if (!article) {
    return (
      <>
        <Ticker />
        <Masthead />
        <div className="page" style={{ padding: "4rem 2rem", textAlign: "center", fontFamily: "var(--fm)", fontSize: ".8rem", color: "var(--ink4)" }}>
          Article not found. <span style={{ cursor: "pointer", color: "var(--accent)", textDecoration: "underline" }} onClick={() => router.push("/")}>Return to feed</span>
        </div>
      </>
    );
  }

  async function askQA(question) {
    const q = (question || qaInput).trim();
    if (!q || qaLoading) return;
    setQaInput("");
    setQaLoading(true);
    setQaMessages((prev) => [
      ...prev,
      { role: "user", text: q },
      { role: "assistant", text: "Thinking…", loading: true },
    ]);

    try {
      const res = await fetch("/api/qa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ articleId: article.id, question: q }),
      });
      const data = await res.json();
      const answer = res.ok ? data.answer : "Unable to answer right now. Please try again.";
      setQaMessages((prev) => {
        const msgs = [...prev];
        msgs[msgs.length - 1] = { role: "assistant", text: answer, loading: false };
        return msgs;
      });
    } catch {
      setQaMessages((prev) => {
        const msgs = [...prev];
        msgs[msgs.length - 1] = { role: "assistant", text: "Unable to answer right now.", loading: false };
        return msgs;
      });
    } finally {
      setQaLoading(false);
    }
  }

  return (
    <>
      <Head>
        <title>{article.headline} · Meridian</title>
        <meta name="description" content={article.subheadline} />
      </Head>
      <Ticker />
      <Masthead />

      <div className="art-page fade-in">
        <div className="back-btn" onClick={() => router.push("/")}>
          ← Back to Today&apos;s Edition
        </div>

        <div className="art-kicker">{article.category}</div>
        <h1 className="art-h">{article.headline}</h1>
        <div className="art-dek">{article.subheadline}</div>
        <div className="art-byline">
          <span>{article.byline}</span>
          <span className="bsep" />
          <span>{article.timestamp}</span>
          <span className="bsep" />
          <span>{article.readtime}</span>
        </div>

        <div
          className="art-body"
          dangerouslySetInnerHTML={{ __html: article.body }}
        />

        {/* ── Q&A ── */}
        <div className="qa-section">
          <div className="qa-title">
            Ask About This Story <span>AI</span>
          </div>
          <div className="qa-chips">
            {QA_CHIPS.map((c) => (
              <button key={c} className="qa-chip" onClick={() => askQA(c)}>
                {c}
              </button>
            ))}
          </div>
          {qaMessages.length > 0 && (
            <div className="qa-messages">
              {qaMessages.map((m, i) => (
                <div key={i} className={m.role === "user" ? "qa-q" : `qa-a${m.loading ? " loading" : ""}`}>
                  {m.text}
                </div>
              ))}
            </div>
          )}
          <div className="qa-row">
            <input
              className="qa-input"
              value={qaInput}
              onChange={(e) => setQaInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !qaLoading && askQA()}
              placeholder="Ask a question about this story…"
              disabled={qaLoading}
            />
            <button className="qa-send" onClick={() => askQA()} disabled={qaLoading}>
              Ask ↗
            </button>
          </div>
        </div>

        {/* ── TRANSPARENCY NOTE ── */}
        <div style={{ marginTop: "2.5rem", paddingTop: "1.2rem", borderTop: "var(--rule)" }}>
          <p style={{ fontSize: ".8rem", color: "var(--ink4)", fontFamily: "var(--fm)", lineHeight: 1.65 }}>
            This article was researched, structured, and written by Meridian&apos;s autonomous AI editorial pipeline
            via a four-stage process: Topic Discovery → Angle Expansion → Article Generation → Publication.
            All factual claims are drawn from publicly available information as of the article&apos;s timestamp.
            Uncertainty is flagged explicitly throughout. No human editor was involved in the editorial process.
          </p>
          {article.pipeline && (
            <p style={{ fontSize: ".72rem", color: "var(--ink4)", fontFamily: "var(--fm)", marginTop: ".5rem" }}>
              Pipeline stages completed: {article.pipeline.stagesCompleted?.join(" → ")}
            </p>
          )}
        </div>
      </div>

      <div className="page">
        <Footer />
      </div>
    </>
  );
}

export async function getServerSideProps({ params }) {
  const { getArticle } = await import("../../lib/store");
  const article = getArticle(params.id);
  if (!article) return { props: { article: null } };
  return { props: { article } };
}
