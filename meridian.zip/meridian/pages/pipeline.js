import Head from "next/head";
import { Ticker, Masthead, Footer } from "../components/Layout";

const PIPELINE_STAGES = [
  {
    num: "01",
    title: "Topic Discovery",
    description:
      "The pipeline identifies high-signal topics from simulated real-world signals — market moves, diplomatic activity, policy shifts, scientific releases. In production, this connects to news APIs and trend data. Topics are scored for newsworthiness, not virality.",
    prompt: `// Simulated trending topics — production connects to news APIs
const topics = await fetchTrendingTopics();
// Returns: { topic, category, signal }
// e.g. { topic: "Federal Reserve rate decision",
//         category: "Economics",
//         signal: "High — FOMC meeting this week" }`,
  },
  {
    num: "02",
    title: "Angle Expansion",
    description:
      "A dedicated Claude call analyses the selected topic and returns a structured editorial brief: the primary angle, key tensions to cover, required data points, and a skeleton of section headings. This separates editorial judgment from prose generation.",
    prompt: `You are a senior editor at a publication like The Economist.
Given topic: "${"${topic}"}" (category: ${"{category}"})

Return JSON:
{
  "primaryAngle": "most newsworthy analytical angle",
  "context": "why this matters now",
  "keyTensions": ["tension 1", "tension 2", "tension 3"],
  "sections": ["heading 1", "heading 2", "heading 3", "heading 4"],
  "dataNeeds": ["specific stat 1", "stat 2"],
  "whatWeKnow": ["fact 1", "fact 2", "fact 3"],
  "whatWeDontKnow": ["unknown 1", "unknown 2", "unknown 3"]
}`,
  },
  {
    num: "03",
    title: "Article Generation",
    description:
      "The article is generated from the structured brief, not from an open-ended prompt. The system prompt encodes Meridian's house style — economical prose, mandatory data points, explicit uncertainty flags, and a required 'What we know / What we don't know' section. The brief acts as a guardrail against generic output.",
    prompt: `SYSTEM: You are the editorial AI for Meridian. Prose is precise, 
analytically rigorous. No marketing language. Uncertainty must be 
acknowledged explicitly. Data points ground every major claim.

USER: Write a full article.
Topic: "${"${topic}"}"
Primary angle: ${"{angles.primaryAngle}"}
Sections: ${"{angles.sections.join(', ')}"}
Key tensions: ${"{angles.keyTensions.join('; ')}"}
Data needed: ${"{angles.dataNeeds.join('; ')}"}
What we know: ${"{angles.whatWeKnow.join('; ')}"}
What we don't know: ${"{angles.whatWeDontKnow.join('; ')}"}

Return JSON: { headline, subheadline, byline, readtime, digest, body }`,
  },
  {
    num: "04",
    title: "Storage & Publication",
    description:
      "The assembled article record is stored (in-memory for demo; swap Upstash Redis or PlanetScale for production persistence) and immediately available at its own URL. The homepage feed updates instantly. Every article carries a machine-readable pipeline trace.",
    prompt: `// Article record structure
{
  id: "art_${"{timestamp}"}",
  headline, subheadline, byline,
  category, readtime, digest,
  body,           // full HTML
  timestamp,      // human-readable
  publishedAt,    // ISO 8601
  pipeline: {
    stagesCompleted: [
      "Topic Discovery",
      "Angle Expansion",
      "Article Generation",
      "Publication"
    ],
    generatedAt: "${"{ISO timestamp}"}"
  }
}`,
  },
];

export default function PipelinePage() {
  return (
    <>
      <Head>
        <title>The Pipeline · Meridian</title>
      </Head>
      <Ticker />
      <Masthead activePage="pipeline" />

      <div className="pipeline-page fade-in">
        <h1>The Editorial Pipeline</h1>
        <p className="intro">
          Every Meridian article is produced by a four-stage autonomous pipeline.
          No human makes an editorial decision. The stages below show exactly what runs —
          including the prompts used at each step.
        </p>

        {PIPELINE_STAGES.map((s, i) => (
          <div key={s.num}>
            <div className="stage-block">
              <div className="stage-num">{s.num}</div>
              <div className="stage-content">
                <h3>{s.title}</h3>
                <p>{s.description}</p>
                <div className="prompt-label">Code / Prompt</div>
                <div className="prompt-box">{s.prompt}</div>
              </div>
            </div>
            {i < PIPELINE_STAGES.length - 1 && <div className="stage-connector" />}
          </div>
        ))}

        <div
          style={{
            marginTop: "3rem",
            padding: "1.5rem",
            background: "var(--paper2)",
            borderLeft: "3px solid var(--accent)",
            fontFamily: "var(--fm)",
            fontSize: ".8rem",
            color: "var(--ink3)",
            lineHeight: 1.7,
          }}
        >
          <strong style={{ color: "var(--ink)", display: "block", marginBottom: ".4rem" }}>
            Why this matters for editorial quality
          </strong>
          Separating angle discovery (Stage 2) from prose generation (Stage 3) is the key architectural
          decision. Open-ended text generation produces generic summaries. Structured briefs produce
          articles with genuine analytical shape — a specific angle, identified tensions, required data,
          and explicit uncertainty — because the model is constrained to address those elements.
        </div>
      </div>

      <div className="page">
        <Footer />
      </div>
    </>
  );
}
