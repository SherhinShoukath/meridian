import { useState, useEffect } from "react";
import Head from "next/head";
import { useRouter } from "next/router";
import { Ticker, Masthead, SecNav, Footer } from "../components/Layout";

const STAGES = [
  "Topic Discovery",
  "Angle Expansion",
  "Fact Framework",
  "Draft Generation",
  "Editorial Pass",
  "Publication",
];

export default function Home({ initialArticles }) {
  const router = useRouter();
  const [articles, setArticles] = useState(initialArticles || []);
  const [category, setCategory] = useState("All");
  const [topic, setTopic] = useState("");
  const [generating, setGenerating] = useState(false);
  const [stage, setStage] = useState(-1);
  const [pending, setPending] = useState(null);
  const [error, setError] = useState(null);

  const filtered =
    category === "All" ? articles : articles.filter((a) => a.category === category);
  const [featured, ...rest] = filtered.length ? filtered : articles;
  const secondary = rest.slice(0, 4);
  const grid = filtered.slice(1);
  const digest = articles.slice(0, 4);

  async function generate() {
    const t = topic.trim();
    if (!t || generating) return;
    setPending(t);
    setTopic("");
    setGenerating(true);
    setError(null);
    setStage(0);

    // animate stages
    let i = 0;
    const iv = setInterval(() => {
      if (i < STAGES.length - 2) { setStage(++i); }
      else clearInterval(iv);
    }, 2200);

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: t }),
      });
      const data = await res.json();
      clearInterval(iv);
      setStage(STAGES.length - 1);

      if (!res.ok) throw new Error(data.error || "Pipeline failed");

      await new Promise((r) => setTimeout(r, 600));
      setArticles((prev) => [data.article, ...prev]);
      router.push(`/article/${data.article.id}`);
    } catch (err) {
      clearInterval(iv);
      setError(err.message);
    } finally {
      setGenerating(false);
      setPending(null);
      setStage(-1);
    }
  }

  return (
    <>
      <Head>
        <title>Meridian · AI News Intelligence</title>
      </Head>
      <Ticker />
      <Masthead activePage="home" />
      <SecNav activeCategory={category} onCategory={setCategory} />

      <div className="page fade-in">
        {/* ── HERO ── */}
        {featured && (
          <div className="hero-wrap">
            <div className="hero-grid">
              <div className="hero-main">
                <div className="hero-kicker">{featured.category}</div>
                <div className="hero-h" onClick={() => router.push(`/article/${featured.id}`)}>
                  {featured.headline}
                </div>
                <div className="hero-dek">{featured.subheadline}</div>
                <div className="hero-byline">
                  <span>{featured.byline}</span>
                  <span className="bsep" />
                  <span>{featured.timestamp}</span>
                  <span className="bsep" />
                  <span>{featured.readtime}</span>
                </div>
              </div>
              <div className="hero-side">
                {secondary.map((a, i) => (
                  <div key={a.id} className="scard" onClick={() => router.push(`/article/${a.id}`)}>
                    <div className="sc-n">0{i + 2}</div>
                    <div className="sc-h">{a.headline}</div>
                    <div className="sc-tag">{a.category} · {a.readtime}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── GENERATE ── */}
        <div className="sdiv">
          <span className="sdiv-title">Generate New Story</span>
          <div className="sdiv-line" />
        </div>
        <div className="gen-section">
          <div className="how-it-works">
            <b>Meridian AI Editorial Pipeline</b>
            Type any topic. Six automated stages run: Topic Discovery → Angle Expansion → Fact Framework → Draft Generation → Editorial Pass → Publication. The finished article appears in the feed instantly.
          </div>
          <div className="gen-row">
            <input
              className="gen-input"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !generating && generate()}
              placeholder='e.g. "Federal Reserve rate hold", "India-China border talks", "OPEC output strategy"'
              disabled={generating}
            />
            <button className="gen-btn" onClick={generate} disabled={generating}>
              {generating ? <><span className="spinner" /> Writing…</> : "✦ Generate Article"}
            </button>
          </div>
          {error && <div className="error-msg">⚠ {error}</div>}

          {generating && (
            <>
              <div className="pipeline-wrap">
                <div className="pip-label">AI Editorial Pipeline — Active</div>
                <div className="pip-stages">
                  {STAGES.map((s, i) => (
                    <>
                      <span key={s} className={`pstage${i < stage ? " done" : i === stage ? " active" : ""}`}>{s}</span>
                      {i < STAGES.length - 1 && <span className="parr">→</span>}
                    </>
                  ))}
                </div>
              </div>
              <div className="pending-box">
                <div className="pulsedot" />
                <div className="pending-text">
                  <strong>Researching and writing your article…</strong>
                  Topic: <div className="pending-topic">{pending}</div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* ── DIGEST STRIP ── */}
      {digest.length > 0 && (
        <div className="digest-strip">
          <div className="digest-inner">
            <div className="digest-header">
              <span className="digest-title">Brief Digest — Today&apos;s Stories</span>
              <span className="digest-sub">Key facts, ~60 words each</span>
            </div>
            <div className="digest-grid">
              {digest.map((a) => (
                <div key={a.id} className="digest-card" onClick={() => router.push(`/article/${a.id}`)}>
                  <div className="dc-cat">{a.category}</div>
                  <div className="dc-h">{a.headline.split(":")[0]}</div>
                  <div className="dc-sum">{a.digest}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── GRID ── */}
      <div className="page">
        <div className="sdiv">
          <span className="sdiv-title">All Stories</span>
          <div className="sdiv-line" />
        </div>
        <div className="grid-3">
          {grid.map((a, idx) => (
            <div key={a.id} className="acard fade-in" onClick={() => router.push(`/article/${a.id}`)}>
              {idx === 0 && articles.indexOf(a) === 0 && (
                <div className="new-badge">New</div>
              )}
              <div className="ac-tag">{a.category}</div>
              <div className="ac-h">{a.headline}</div>
              <div className="ac-dek">{a.subheadline}</div>
              <div className="ac-meta">{a.byline} · {a.readtime}</div>
            </div>
          ))}
        </div>
        <Footer />
      </div>
    </>
  );
}

export async function getServerSideProps() {
  const { getArticles } = await import("../lib/store");
  const articles = getArticles().map((a) => ({
    id: a.id,
    category: a.category,
    headline: a.headline,
    subheadline: a.subheadline,
    byline: a.byline,
    readtime: a.readtime,
    digest: a.digest || a.subheadline,
    timestamp: a.timestamp,
    publishedAt: a.publishedAt,
  }));
  return { props: { initialArticles: articles } };
}
