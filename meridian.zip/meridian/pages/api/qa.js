import Anthropic from "@anthropic-ai/sdk";
import { getArticle } from "../../lib/store";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { articleId, question } = req.body || {};
  if (!articleId || !question) {
    return res.status(400).json({ error: "articleId and question required" });
  }

  const article = getArticle(articleId);
  if (!article) return res.status(404).json({ error: "Article not found" });

  const bodyText = article.body.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(0, 1200);

  try {
    const msg = await client.messages.create({
      model: "claude-opus-4-5",
      max_tokens: 300,
      system:
        "You are Meridian's editorial AI. Answer reader questions about articles concisely — 2 to 4 sentences. Be precise and analytically grounded. Acknowledge uncertainty explicitly. No filler phrases.",
      messages: [
        {
          role: "user",
          content: `Article: "${article.headline}"\n\nBody excerpt: ${bodyText}\n\nReader question: ${question}\n\nAnswer directly.`,
        },
      ],
    });

    res.status(200).json({ answer: msg.content[0].text });
  } catch (err) {
    console.error("Q&A error:", err);
    res.status(500).json({ error: "Failed to generate answer" });
  }
}
