import { getArticle } from "../../../lib/store";

export default function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const { id } = req.query;
  const article = getArticle(id);
  if (!article) return res.status(404).json({ error: "Not found" });
  res.status(200).json({ article });
}
