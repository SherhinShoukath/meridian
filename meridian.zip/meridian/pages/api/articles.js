import { getArticles } from "../../lib/store";

export default function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const articles = getArticles().map((a) => ({
    id: a.id,
    category: a.category,
    headline: a.headline,
    subheadline: a.subheadline,
    byline: a.byline,
    readtime: a.readtime,
    digest: a.digest,
    timestamp: a.timestamp,
    publishedAt: a.publishedAt,
  }));
  res.status(200).json({ articles });
}
