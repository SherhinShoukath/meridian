import {
  fetchTrendingTopics,
  expandAngles,
  generateArticle,
  assembleArticle,
} from "../../lib/pipeline";
import { addArticle } from "../../lib/store";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { topic: customTopic, category: customCategory } = req.body || {};

  try {
    // ── Stage 1: Topic ────────────────────────────────────────────
    let topic, category;
    if (customTopic) {
      topic = customTopic;
      category = customCategory || "Analysis";
    } else {
      const trends = await fetchTrendingTopics();
      const picked = trends[Math.floor(Math.random() * trends.length)];
      topic = picked.topic;
      category = picked.category;
    }

    // ── Stage 2: Angles ───────────────────────────────────────────
    const angles = await expandAngles(topic, category);

    // ── Stage 3: Article ──────────────────────────────────────────
    const articleData = await generateArticle(topic, category, angles);

    // ── Stage 4: Store + return ───────────────────────────────────
    const article = assembleArticle(topic, category, articleData);
    addArticle(article);

    res.status(200).json({ article });
  } catch (err) {
    console.error("Pipeline error:", err);
    res.status(500).json({ error: err.message || "Pipeline failed" });
  }
}
