import Head from "next/head";
import { Ticker, Masthead, Footer } from "../components/Layout";

export default function AboutPage() {
  return (
    <>
      <Head>
        <title>About Meridian · AI News Intelligence</title>
      </Head>
      <Ticker />
      <Masthead activePage="about" />

      <div className="about-page fade-in">
        <h1>About Meridian</h1>
        <div className="lead">
          Meridian is an AI-native news platform where every editorial decision — topic selection,
          angle development, structure, and tone — is handled by an autonomous pipeline.
          No human is in the editorial path.
        </div>

        <h2>The editorial standard</h2>
        <p>
          The pipeline is designed to produce articles that meet the depth and analytical rigour
          associated with publications like The Economist and Reuters — not summaries, not
          SEO copy, not news aggregation. Each article has a specific analytical angle,
          structured sections, grounded data points, and explicit uncertainty flags.
        </p>
        <p>
          The &quot;What we know / What we don&apos;t know&quot; section is mandatory on every piece.
          It forces the pipeline to distinguish established fact from inference,
          and inference from genuine uncertainty. That distinction is the foundation
          of credible reporting.
        </p>

        <h2>Why AI-native, not AI-assisted</h2>
        <p>
          Most AI journalism tools position AI as a drafting aid for human writers.
          Meridian inverts this: the pipeline produces complete editorial output,
          and the question being tested is whether it can meet a serious journalistic standard
          without human intervention at any stage.
        </p>
        <p>
          This is not a claim that AI journalism is superior to human journalism.
          It is an experiment in how far autonomous editorial pipelines can go —
          and a demonstration of what they produce when designed with genuine editorial
          instinct rather than throughput optimisation.
        </p>

        <h2>What this is not</h2>
        <p>
          Meridian is not a content farm. The pipeline does not optimise for volume,
          SEO ranking, or engagement metrics. It optimises for the depth and credibility
          a serious reader would expect from a premium news source.
        </p>
        <p>
          All generated content should be treated as AI-produced analysis, not verified reporting.
          Data points and factual claims are drawn from the model&apos;s training knowledge and
          are clearly timestamped. Readers are expected to verify specific claims independently.
        </p>

        <h2>The technology</h2>
        <p>
          Built on Next.js, deployed on Vercel, powered by Claude (Anthropic).
          The four-stage pipeline — Topic Discovery, Angle Expansion, Article Generation,
          Publication — is described in detail on the{" "}
          <a href="/pipeline" style={{ color: "var(--accent)", textDecoration: "underline" }}>
            Pipeline page
          </a>
          .
        </p>

        <div
          style={{
            marginTop: "2.5rem",
            padding: "1.2rem 1.5rem",
            background: "var(--paper2)",
            border: "var(--rule)",
            fontFamily: "var(--fm)",
            fontSize: ".75rem",
            color: "var(--ink4)",
            lineHeight: 1.7,
          }}
        >
          Built for the Meridian AI Journalism Hackathon, April 2026.
          All articles generated autonomously by Claude via a structured editorial pipeline.
          No editorial decisions were made by human editors.
        </div>
      </div>

      <div className="page">
        <Footer />
      </div>
    </>
  );
}
